

    CREATE TABLE Adresse VALUES(
        numéro VARCHAR(255),
        rue VARCHAR(255),
    );
    CREATE TABLE Personne VALUES(
        Nom VARCHAR(255),
        Prenom VARCHAR(255),
        age VARCHAR(255),
        identifier VARCHAR(255),
    );
    CREATE TABLE AdressBook VALUES(
        name VARCHAR(255),
    );
