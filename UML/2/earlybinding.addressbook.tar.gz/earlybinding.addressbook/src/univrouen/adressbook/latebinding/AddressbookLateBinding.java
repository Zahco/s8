package univrouen.adressbook.latebinding;

public class AddressbookLateBinding {

}
